// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket;

import javax.net.ssl.SSLSession;
import org.java_websocket.enums.ReadyState;
import org.java_websocket.drafts.Draft;
import java.net.InetSocketAddress;
import org.java_websocket.enums.Opcode;
import java.util.Collection;
import org.java_websocket.framing.Framedata;
import java.nio.ByteBuffer;

public interface WebSocket
{
    void close(final int p0, final String p1);
    
    void close(final int p0);
    
    void close();
    
    void closeConnection(final int p0, final String p1);
    
    void send(final String p0);
    
    void send(final ByteBuffer p0);
    
    void send(final byte[] p0);
    
    void sendFrame(final Framedata p0);
    
    void sendFrame(final Collection<Framedata> p0);
    
    void sendPing();
    
    void sendFragmentedFrame(final Opcode p0, final ByteBuffer p1, final boolean p2);
    
    boolean hasBufferedData();
    
    InetSocketAddress getRemoteSocketAddress();
    
    InetSocketAddress getLocalSocketAddress();
    
    boolean isOpen();
    
    boolean isClosing();
    
    boolean isFlushAndClose();
    
    boolean isClosed();
    
    Draft getDraft();
    
    ReadyState getReadyState();
    
    String getResourceDescriptor();
    
     <T> void setAttachment(final T p0);
    
     <T> T getAttachment();
    
    boolean hasSSLSupport();
    
    SSLSession getSSLSession() throws IllegalArgumentException;
}
