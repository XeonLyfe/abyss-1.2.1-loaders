// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.extensions.permessage_deflate;

import org.java_websocket.exceptions.InvalidFrameException;
import org.java_websocket.framing.BinaryFrame;
import org.java_websocket.framing.TextFrame;
import org.java_websocket.extensions.IExtension;
import org.java_websocket.extensions.ExtensionRequestData;
import org.java_websocket.framing.ContinuousFrame;
import java.nio.ByteBuffer;
import org.java_websocket.framing.FramedataImpl1;
import java.util.zip.DataFormatException;
import java.io.ByteArrayOutputStream;
import org.java_websocket.exceptions.InvalidDataException;
import org.java_websocket.enums.Opcode;
import org.java_websocket.framing.DataFrame;
import org.java_websocket.framing.Framedata;
import java.util.LinkedHashMap;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.Map;
import org.java_websocket.extensions.CompressionExtension;

public class PerMessageDeflateExtension extends CompressionExtension
{
    private static final String EXTENSION_REGISTERED_NAME = "permessage-deflate";
    private static final String SERVER_NO_CONTEXT_TAKEOVER = "server_no_context_takeover";
    private static final String CLIENT_NO_CONTEXT_TAKEOVER = "client_no_context_takeover";
    private static final String SERVER_MAX_WINDOW_BITS = "server_max_window_bits";
    private static final String CLIENT_MAX_WINDOW_BITS = "client_max_window_bits";
    private static final int serverMaxWindowBits = 32768;
    private static final int clientMaxWindowBits = 32768;
    private static final byte[] TAIL_BYTES;
    private static final int BUFFER_SIZE = 1024;
    private boolean serverNoContextTakeover;
    private boolean clientNoContextTakeover;
    private Map<String, String> requestedParameters;
    private Inflater inflater;
    private Deflater deflater;
    
    public PerMessageDeflateExtension() {
        this.serverNoContextTakeover = true;
        this.clientNoContextTakeover = false;
        this.requestedParameters = new LinkedHashMap<String, String>();
        this.inflater = new Inflater(true);
        this.deflater = new Deflater(-1, true);
    }
    
    @Override
    public void decodeFrame(final Framedata inputFrame) throws InvalidDataException {
        if (!(inputFrame instanceof DataFrame)) {
            return;
        }
        if (inputFrame.getOpcode() == Opcode.CONTINUOUS && inputFrame.isRSV1()) {
            throw new InvalidDataException(1008, "RSV1 bit can only be set for the first frame.");
        }
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        try {
            this.decompress(inputFrame.getPayloadData().array(), output);
            if (this.inflater.getRemaining() > 0) {
                this.inflater = new Inflater(true);
                this.decompress(inputFrame.getPayloadData().array(), output);
            }
            if (inputFrame.isFin()) {
                this.decompress(PerMessageDeflateExtension.TAIL_BYTES, output);
                if (this.clientNoContextTakeover) {
                    this.inflater = new Inflater(true);
                }
            }
        }
        catch (DataFormatException e) {
            throw new InvalidDataException(1008, e.getMessage());
        }
        if (inputFrame.isRSV1()) {
            ((DataFrame)inputFrame).setRSV1(false);
        }
        ((FramedataImpl1)inputFrame).setPayload(ByteBuffer.wrap(output.toByteArray(), 0, output.size()));
    }
    
    private void decompress(final byte[] data, final ByteArrayOutputStream outputBuffer) throws DataFormatException {
        this.inflater.setInput(data);
        final byte[] buffer = new byte[1024];
        int bytesInflated;
        while ((bytesInflated = this.inflater.inflate(buffer)) > 0) {
            outputBuffer.write(buffer, 0, bytesInflated);
        }
    }
    
    @Override
    public void encodeFrame(final Framedata inputFrame) {
        if (!(inputFrame instanceof DataFrame)) {
            return;
        }
        if (!(inputFrame instanceof ContinuousFrame)) {
            ((DataFrame)inputFrame).setRSV1(true);
        }
        this.deflater.setInput(inputFrame.getPayloadData().array());
        final ByteArrayOutputStream output = new ByteArrayOutputStream();
        final byte[] buffer = new byte[1024];
        int bytesCompressed;
        while ((bytesCompressed = this.deflater.deflate(buffer, 0, buffer.length, 2)) > 0) {
            output.write(buffer, 0, bytesCompressed);
        }
        final byte[] outputBytes = output.toByteArray();
        int outputLength = outputBytes.length;
        if (inputFrame.isFin()) {
            if (this.endsWithTail(outputBytes)) {
                outputLength -= PerMessageDeflateExtension.TAIL_BYTES.length;
            }
            if (this.serverNoContextTakeover) {
                this.deflater.end();
                this.deflater = new Deflater(-1, true);
            }
        }
        ((FramedataImpl1)inputFrame).setPayload(ByteBuffer.wrap(outputBytes, 0, outputLength));
    }
    
    private boolean endsWithTail(final byte[] data) {
        if (data.length < 4) {
            return false;
        }
        final int length = data.length;
        for (int i = 0; i < PerMessageDeflateExtension.TAIL_BYTES.length; ++i) {
            if (PerMessageDeflateExtension.TAIL_BYTES[i] != data[length - PerMessageDeflateExtension.TAIL_BYTES.length + i]) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public boolean acceptProvidedExtensionAsServer(final String inputExtension) {
        final String[] split;
        final String[] requestedExtensions = split = inputExtension.split(",");
        for (final String extension : split) {
            final ExtensionRequestData extensionData = ExtensionRequestData.parseExtensionRequest(extension);
            if ("permessage-deflate".equalsIgnoreCase(extensionData.getExtensionName())) {
                final Map<String, String> headers = extensionData.getExtensionParameters();
                this.requestedParameters.putAll(headers);
                if (this.requestedParameters.containsKey("client_no_context_takeover")) {
                    this.clientNoContextTakeover = true;
                }
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean acceptProvidedExtensionAsClient(final String inputExtension) {
        final String[] split;
        final String[] requestedExtensions = split = inputExtension.split(",");
        for (final String extension : split) {
            final ExtensionRequestData extensionData = ExtensionRequestData.parseExtensionRequest(extension);
            if ("permessage-deflate".equalsIgnoreCase(extensionData.getExtensionName())) {
                final Map<String, String> headers = extensionData.getExtensionParameters();
                return true;
            }
        }
        return false;
    }
    
    @Override
    public String getProvidedExtensionAsClient() {
        this.requestedParameters.put("client_no_context_takeover", ExtensionRequestData.EMPTY_VALUE);
        this.requestedParameters.put("server_no_context_takeover", ExtensionRequestData.EMPTY_VALUE);
        return "permessage-deflate; server_no_context_takeover; client_no_context_takeover";
    }
    
    @Override
    public String getProvidedExtensionAsServer() {
        return "permessage-deflate; server_no_context_takeover" + (this.clientNoContextTakeover ? "; client_no_context_takeover" : "");
    }
    
    @Override
    public IExtension copyInstance() {
        return new PerMessageDeflateExtension();
    }
    
    @Override
    public void isFrameValid(final Framedata inputFrame) throws InvalidDataException {
        if ((inputFrame instanceof TextFrame || inputFrame instanceof BinaryFrame) && !inputFrame.isRSV1()) {
            throw new InvalidFrameException("RSV1 bit must be set for DataFrames.");
        }
        if (inputFrame instanceof ContinuousFrame && (inputFrame.isRSV1() || inputFrame.isRSV2() || inputFrame.isRSV3())) {
            throw new InvalidFrameException("bad rsv RSV1: " + inputFrame.isRSV1() + " RSV2: " + inputFrame.isRSV2() + " RSV3: " + inputFrame.isRSV3());
        }
        super.isFrameValid(inputFrame);
    }
    
    @Override
    public String toString() {
        return "PerMessageDeflateExtension";
    }
    
    static {
        TAIL_BYTES = new byte[] { 0, 0, -1, -1 };
    }
}
