// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.handshake;

public interface ClientHandshake extends Handshakedata
{
    String getResourceDescriptor();
}
