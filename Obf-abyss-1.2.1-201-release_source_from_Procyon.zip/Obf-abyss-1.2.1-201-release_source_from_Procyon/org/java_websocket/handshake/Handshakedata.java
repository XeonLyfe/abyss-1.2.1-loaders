// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.handshake;

import java.util.Iterator;

public interface Handshakedata
{
    Iterator<String> iterateHttpFields();
    
    String getFieldValue(final String p0);
    
    boolean hasFieldValue(final String p0);
    
    byte[] getContent();
}
