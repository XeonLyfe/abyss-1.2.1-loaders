// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.interfaces;

import javax.net.ssl.SSLEngine;

public interface ISSLChannel
{
    SSLEngine getSSLEngine();
}
