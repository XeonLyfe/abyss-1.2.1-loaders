// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.server;

import java.io.IOException;
import javax.net.ssl.SSLEngine;
import org.java_websocket.SSLSocketChannel2;
import java.nio.channels.ByteChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.SSLContext;

public class CustomSSLWebSocketServerFactory extends DefaultSSLWebSocketServerFactory
{
    private final String[] enabledProtocols;
    private final String[] enabledCiphersuites;
    
    public CustomSSLWebSocketServerFactory(final SSLContext sslContext, final String[] enabledProtocols, final String[] enabledCiphersuites) {
        this(sslContext, Executors.newSingleThreadScheduledExecutor(), enabledProtocols, enabledCiphersuites);
    }
    
    public CustomSSLWebSocketServerFactory(final SSLContext sslContext, final ExecutorService executerService, final String[] enabledProtocols, final String[] enabledCiphersuites) {
        super(sslContext, executerService);
        this.enabledProtocols = enabledProtocols;
        this.enabledCiphersuites = enabledCiphersuites;
    }
    
    @Override
    public ByteChannel wrapChannel(final SocketChannel channel, final SelectionKey key) throws IOException {
        final SSLEngine e = this.sslcontext.createSSLEngine();
        if (this.enabledProtocols != null) {
            e.setEnabledProtocols(this.enabledProtocols);
        }
        if (this.enabledCiphersuites != null) {
            e.setEnabledCipherSuites(this.enabledCiphersuites);
        }
        e.setUseClientMode(false);
        return new SSLSocketChannel2(channel, e, this.exec, key);
    }
}
