// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.server;

import org.java_websocket.WebSocket;
import java.io.IOException;
import java.nio.channels.ByteChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;
import java.util.List;
import org.java_websocket.WebSocketListener;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.drafts.Draft;
import org.java_websocket.WebSocketAdapter;
import org.java_websocket.WebSocketServerFactory;

public class DefaultWebSocketServerFactory implements WebSocketServerFactory
{
    @Override
    public WebSocketImpl createWebSocket(final WebSocketAdapter a, final Draft d) {
        return new WebSocketImpl(a, d);
    }
    
    @Override
    public WebSocketImpl createWebSocket(final WebSocketAdapter a, final List<Draft> d) {
        return new WebSocketImpl(a, d);
    }
    
    @Override
    public SocketChannel wrapChannel(final SocketChannel channel, final SelectionKey key) {
        return channel;
    }
    
    @Override
    public void close() {
    }
}
