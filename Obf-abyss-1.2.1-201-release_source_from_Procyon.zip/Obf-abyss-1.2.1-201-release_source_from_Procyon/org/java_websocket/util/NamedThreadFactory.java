// 
// Decompiled by Procyon v0.5.36
// 

package org.java_websocket.util;

import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.ThreadFactory;

public class NamedThreadFactory implements ThreadFactory
{
    private final ThreadFactory defaultThreadFactory;
    private final AtomicInteger threadNumber;
    private final String threadPrefix;
    
    public NamedThreadFactory(final String threadPrefix) {
        this.defaultThreadFactory = Executors.defaultThreadFactory();
        this.threadNumber = new AtomicInteger(1);
        this.threadPrefix = threadPrefix;
    }
    
    @Override
    public Thread newThread(final Runnable runnable) {
        final Thread thread = this.defaultThreadFactory.newThread(runnable);
        thread.setName(this.threadPrefix + "-" + this.threadNumber);
        return thread;
    }
}
