// 
// Decompiled by Procyon v0.5.36
// 

package org.yaml.snakeyaml.parser;

import org.yaml.snakeyaml.events.Event;

interface Production
{
    Event produce();
}
